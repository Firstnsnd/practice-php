<?php 
namespace home\model;

use core\Model;
/**
* 	moxing
*/
class UserModel extends Model
{
	
	function __construct()
	{
		parent::__construct('user');
	}

}