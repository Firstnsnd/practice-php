<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>hello</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<h1>hello world</h1>
</body>
</html>